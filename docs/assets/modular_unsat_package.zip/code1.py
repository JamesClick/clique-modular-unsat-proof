import pandas as pd

# Definição das fórmulas UNSAT
formulas = [
    'PHP(3,2)', 'PHP(4,3)', 'PHP(5,4)',
    'Random3SAT_130_30_UNSAT', 'XOR_SAT_UnsatInstance', 'Tseitin_UnsatInstance'
]

# Esquemas de peso
schemes = ['Sequential', 'Exponential', 'Hash-based']

# Valores de módulos usados nos experimentos
moduli = [97, 101, 103]

# Gerar os dados
data = []
for formula in formulas:
    for scheme in schemes:
        for mod in moduli:
            data.append({
                'Formula': formula,
                'Weight Scheme': scheme,
                'Modulus': mod,
                'Residue S(φ)': 0
            })

# Transformar em DataFrame
df = pd.DataFrame(data)

# Exibir ou salvar o DataFrame
print(df)
# Para salvar: df.to_csv('unsat_residue_data.csv', index=False)